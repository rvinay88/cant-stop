//
//  Board.cpp
//  cant-stop
//
//  Created by Vinay  Raghu on 10/25/15.
//  Copyright © 2015 Vinay  Raghu. All rights reserved.
//

#include "Board.hpp"

ostream& Board::print( ostream& out ) {
    for(int i=0; i<13; i++) {
        if(backBone[i] != NULL) {
            backBone[i]->print(cout);
        }
    }
    return out;
}

void Board::startTower(Player *player) {
    currentPlayer = player;
    counter++;
}

bool move(int column) {
    if(true) {
        // if column is pend or cpature
        // or there is no tower available
        return false;
    }
    else {
        // if we have a tower available
        // 
    }
}