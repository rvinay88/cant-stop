//
//  enums.cpp
//  cant-stop
//
//  Created by Vinay  Raghu on 10/23/15.
//  Copyright © 2015 Vinay  Raghu. All rights reserved.
//
#ifndef colors
#define colors
    enum ColorENum { WHITE, ORANGE, YELLOW, GREEN, BLUE };
    extern const char* colorNames[5];
    enum colStatus { AVAILABLE, PENDING, CAPTURED};
    extern const char* statusNames[3];
#endif